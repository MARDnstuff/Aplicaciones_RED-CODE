
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;



public class C1 implements Runnable{
 private ReentrantLock table;
  private Condition condition;    
  
  public C1(){
      condition = table.newCondition();
  }
  
  void llena(){
      int i=0;
  }//llena
  public void run(){
      
  }//run
  
}
