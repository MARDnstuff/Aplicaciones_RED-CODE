import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;



public class EjemploJEditorPane
{
    /**
     * Crea un nuevo objeto EjemploJEditorPane.
     */
    public EjemploJEditorPane()
    {
        try
        {
          // Preparamos la ventana de ejemplo
            JFrame v = new JFrame("JEditorPane con HTML");
            JEditorPane editor = new JEditorPane();
            JScrollPane scroll = new JScrollPane(editor);
            v.getContentPane().add(scroll);
            v.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            
            // Marcamos el editor para que use HTML 
            editor.setContentType("text/html");
            
            // Insertamos un texto
            editor.setText(
            //  "<head><base href=\"file:C:/Users/52552/Documents/NetBeansProjects/EjJeditorPane\"></head>"+        
                    "<head><base href=\"file:C:\\Users\\52552\\Documents\\NetBeansProjects\\EjJeditorPane\\\"></head>"+        
                "<b>hola</b><br>" + "<i>adios</i><br>" +
                "<font face=\"arial\">fuente arial</font><br>" +
                "<font face=\"courier\">fuente courier</font><br>" +
                "<font size=\"24\">fuente grande</font><br>" +
                "<font color=\"red\">color rojo</font><br>" +
                "<img src=\"cara.gif\"></img>");
            
            // Se visualiza la ventana
            v.pack();
            v.setVisible(true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * main de prueba
     *
     * @param args Se ignoran.
     */
    public static void main(String[] args)
    {
        new EjemploJEditorPane();
    }
}