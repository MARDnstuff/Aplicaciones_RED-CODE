// Clase abstracta de la que heredan las clases JugadorMaquina y JugadorHumano

public abstract class Jugador {
	public Jugador() {
		
	}
}
