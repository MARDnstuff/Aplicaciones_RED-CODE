import java.io.*;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
/**
 *
 * @author axel
 */
public class Reproduce extends Thread{
    File archivo;
    
    public Reproduce(File archivo){
        this.archivo=archivo;
    }
    ///////////////////////////////////////////////////////7
    public void testPlay(String filename)
{
  try {
    File file = new File(filename);
    AudioInputStream in= AudioSystem.getAudioInputStream(file);
    AudioInputStream din = null;
    AudioFormat baseFormat = in.getFormat();
    AudioFormat decodedFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 
                                                                                  baseFormat.getSampleRate(),
                                                                                  16,
                                                                                  baseFormat.getChannels(),
                                                                                  baseFormat.getChannels() * 2,
                                                                                  baseFormat.getSampleRate(),
                                                                                  false);
    din = AudioSystem.getAudioInputStream(decodedFormat, in);
    // Play now. 
    rawplay(decodedFormat, din);
    in.close();
  } catch (Exception e)
    {
        //Handle exception.
    }
} 

private void rawplay(AudioFormat targetFormat, AudioInputStream din) throws Exception/*,LineUnavailableException*/
{
  byte[] data = new byte[4096];
  SourceDataLine line = getLine(targetFormat); 
  if (line != null)
  {
    // Start
    line.start();
    int nBytesRead = 0, nBytesWritten = 0;
    while (nBytesRead != -1)
    {
        nBytesRead = din.read(data, 0, data.length);
        if (nBytesRead != -1) nBytesWritten = line.write(data, 0, nBytesRead);
    }
    // Stop
    line.drain();
    line.stop();
    line.close();
    din.close();
  } 
}

private SourceDataLine getLine(AudioFormat audioFormat) throws Exception/*LineUnavailableException*/
{
  SourceDataLine res = null;
  DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
  res = (SourceDataLine) AudioSystem.getLine(info);
  res.open(audioFormat);
  return res;
} 
//////////////////////////////////////////////////////////7    
public void run(){
    try{
        testPlay(this.archivo.getAbsolutePath());
    }catch(Exception e){
        e.printStackTrace();
    }//catch
}//run
}
