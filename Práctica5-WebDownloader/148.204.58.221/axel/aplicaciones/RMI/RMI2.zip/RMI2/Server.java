package hello;
	
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
	
public class Server implements Suma {
	
    public Server() {}

    public int suma(int a, int b) {
	return a+b;
    }
	
    public static void main(String args[]) {
	try {
		 java.rmi.registry.LocateRegistry.createRegistry(1099); //puerto default del rmiregistry
		 System.out.println("RMI registry ready.");
	  } catch (Exception e) {
		 System.out.println("Exception starting RMI registry:");
		 e.printStackTrace();
	  }//catch
	
	try {
		System.setProperty("java.rmi.server.codebase","file:///f:\\redes2\\RMI\\RMI2");
	    Server obj = new Server();
	    Suma stub = (Suma) UnicastRemoteObject.exportObject(obj, 0);

	    // Bind the remote object's stub in the registry
	    Registry registry = LocateRegistry.getRegistry();
	    registry.bind("Suma", stub);

	    System.err.println("Servidor listo...");
	} catch (Exception e) {
	    System.err.println("Server exception: " + e.toString());
	    e.printStackTrace();
	}
    }
}
